# MicroTranslate — GitHub Pages

Upload all files in this folder to the root of a GitHub repository.

Then:
1. Repository → Settings → Pages.
2. Source → Deploy from a branch.
3. Branch → `main`, folder → `/(root)`.
4. Save.
5. Open the Pages URL GitHub shows you.
6. Paste your OAuth owner-only **Access token**, optionally tick “Nhớ token trên thiết bị này”, then Test token.
7. On iPhone Safari: Share → Add to Home Screen → Open as Web App.

Never commit the OAuth access token or client secret into this repository.
